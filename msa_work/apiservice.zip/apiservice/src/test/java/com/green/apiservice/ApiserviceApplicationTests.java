package com.green.apiservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
